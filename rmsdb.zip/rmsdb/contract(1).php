<html>
    <head>
    <meta charset="utf-8">
    <title>Contract Us</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
        <link href='https://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
        <link href='custom.css' rel='stylesheet' type='text/css'>
        <link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet"> 

<style type="text/css">
    body{
        background-image: url(contract-3.jpg);
        background-size: cover;
        background-attachment: fixed;
    }

    .inner p{
    color: white;
    font-size: 65px;
    font-family: 'lobster',cursive;
    text-align: center;

}

</style>

    </head>
<body>
    <div class="container">
        <div class="inner">
        </br></br></br></br></br>
            <p><b>Hi...!!! How Can I Help You??</b></p></br>
        </div>
    <body>
    
        <div class="content">

                    <div class="container">

            <div class="row">

                <div class="col-lg-8 col-lg-offset-2">

                    <form id="contact-form" method="post" role="form" action="con(1)_fun.php">

                        <div class="messages"></div>

                        <div class="controls">

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_name"><font font color="black" font size="5">Firstname *</font></label>
                                        <input type="text" name="fname" class="form-control" placeholder="Please enter your firstname *" required="required" data-error="Firstname is required.">
                               
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_lastname"><font font color="black" font size="5">Lastname *</font></label>
                                        <input type="text" name="lname" class="form-control" placeholder="Please enter your lastname *" required="required" data-error="Lastname is required.">
                      
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_email"><font font color="black" font size="5">Email *</font></label>
                                        <input type="email" name="email" class="form-control" placeholder="Please enter your email *" required="required" data-error="Valid email is required.">
                                     
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_phone"><font font color="black" font size="5">Phone</font></label>
                                        <input type="phone" name="phone" class="form-control" placeholder="Please enter your phone">
                                
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="form_message"><font font color="black" font size="5">Message *</font></label>
                                        <textarea name="msg" class="form-control" placeholder="Message for me *" rows="4" required="required" data-error="Please,leave us a message."></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <input type="submit" class="btn btn-success btn-send" value="Send message">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <p class="text-muted"><strong>*</strong> <font font color="black" font size="3">These fields are required. Contact form by</font><font font color="blue" font size="3"><b> Food Hunter</b></font></p>
                                </div>
                            </div>
                        </div>
                    </form>
