<?php
try {
	
	$db = new mysqli("localhost","root","","rmsdb");


} catch (Exception $exc) {
	echo $exc->getTraceAsString();	
}

if(isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['email']) && isset($_POST['phone']) && isset($_POST['msg'])){


	$fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $msg = $_POST['msg'];

    $is_insert = $db->query("INSERT INTO `contact_us`(`fname`, `lname`, `email`, `phone`, `msg`) VALUES ('$fname','$lname','$email','$phone','$msg')");


    if($is_insert == TRUE) {
    	 echo "<script>alert('Thanks, Your message is submitted.')</script>";
      echo "<script>window.open('contract(1).php','_self')</script>";
    }



}

?>