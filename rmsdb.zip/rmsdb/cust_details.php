<!DOCTYPE html>
<?php include("func.php");?>
<html>
<head>
	<title>Customer_Details</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="manager.css">
</head>
<body>
<div class="jumbotron" style="background:url('r2.jpg') no-repeat;background-size: cover;height: 700px;">
		<div class="inner">
		<p>Cutomers Details</p>	
		</div>
		<br><br><br><br><br><br>
		<div class="container-fluid">
			<div class="card">
				<div class="card-body" style="background-color:#3498DB;color: #ffffff;">
					<div></div>
					<a href="Manager.php" class="btn btn-light">Go Back</a>
					Customer_Details
				</div><br>
				<div class="col-md-8"><br>
					<form class="form-group" action="search_cust.php" method="post">
						<div class="row">
							<div class="col-md-6"><input type="text" name="search" class="form-control" placeholder="enter contact no. "></div>
							<div class="col-md-2"><input type="submit" name="cust_search_submit" class="btn btn-primary" value="Search"></div>
						</div>
					</form>
				</div>
				<div class="card-body">
<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Address</th>
      <th scope="col">Email add.</th>
      <th scope="col">Contact No.</th>


    </tr>
  </thead>
  <tbody>
   <?php get_customer_details(); ?> 
    
  </tbody>
</table>















<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
</body>
</html>