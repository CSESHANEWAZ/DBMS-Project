<html>
<head>
  <title>Water_Details</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>
<body>
<?php 
include("func.php");
if(isset($_POST['water_search_submit']))
{
  $contact=$_POST['contact'];
  $query="select * from add_water where contact='$contact'";
  $result=mysqli_query($con,$query);
  echo "<div class='container-fluid'>
  <div class='card'>
  <div class='card-body'><a href='water_details.php' class='btn btn-primary'>Go back</a></div>
  img src='images/r2.jpg' class='card-img-top'>
  <div class='card-body' style='background-color:#3498DB;color:#ffffff;'>
<table class='table table-hover'>
  <thead>
    <tr>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Address</th>
      <th>Email address</th>
      <th>Contact No.</th>
    </tr>
  </thead>
  <tbody>"
  ;
  while($row=mysqli_fetch_array($result)) {
  $fname=$row['fname'];
    $lname=$row['lname'];
    $address=$row['address'];
    $email=$row['email'];
    $contact=$row['contact'];
    echo "<tr>
    <td>$fname</td>
    <td>$lname</td>
    <td>$address</td>
    <td>$email</td>
    <td>$contact</td>
    </tr>";
  }
  echo "</tbody></table></div></div></div>";
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" 
integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" 
crossorigin="anonymous"></script>
</body>
</html>