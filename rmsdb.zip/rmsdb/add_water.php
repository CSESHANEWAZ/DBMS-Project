<!DOCTYPE html>
<html>
<head>
	<title>Add Waiter</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="func.php">
	<link rel="stylesheet" type="text/css" href="manager.css">
</head>
<body>
	<div class="jumbotron" style="background:url('cus-1.jpg') no-repeat;background-size: cover;height: 700px;">
		<div class="inner">
		<p>ADD NEW Waiter</p>	
		</div>
		<br><br><br><br><br><br>


		<div class="col-md-8">
			<div class="card">
				<div class="card-body" style="background-color:#3498DB;color: #ffffff;">
					<h3>Add New Waiter</h3>
				</div>
				<div class="card-body">
					<form class="form-group" action="func.php" method="post">
						<label>First Name :</label>
						<input type="text" name="fname" class="form-control"><br>
						<label>Last Name :</label>
						<input type="text" name="lname" class="form-control"><br>
						<label>Address :</label>
						<input type="text" name="address" class="form-control"><br>
						<label>Email id: :</label>
						<input type="text" name="email" class="form-control"><br>
						<label>Contact :</label>
						<input type="text" name="contact" class="form-control"><br>	
						<input type="submit" class="btn btn-primary" name="add_water" value="Add">
					</form>


				</div>
			</div>
		</div>
		<div class="col-md-1"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
</body>
</html>