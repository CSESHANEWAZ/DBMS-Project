<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Satisfy&display=swap" rel="stylesheet"> 

    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="footer.css">  
</head>

<body>
<div class="slider">

	<div class="load">
</div>
	<div class="content">

<header>
	<div class="main">
		<div class="logo">
			<img src="logo.png">
		</div>
		<ul>
			<li class="active"><a href="#">Home</a></li>
			<li><a href="About Us.html">About Us</a></li>
			<li><a href="Manager.php">Admin</a></li>
			<li><a href="Menu.html">Online Order</a></li>
			<li><a href="Gallary.php">Gallary</a></li>
			<li><a href="contract(1).php">Contract Us</a></li>
		</ul>		
	</div>
</header>

		<div class="principal">
			<h1>WELLCOME</h1>
			<p style = "font-family:'Courgette', cursive;">EAT  DRINK &  VISIT</p>
		</div>
	</div>







<!--footer-->
<footer id="footer">
	<div class="footer-top">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-6 footer-info">
					<h3>Food Hunter</h3>
					<p>Food Hunter is a famous resturant for delicious food and good services.This is our Resturant Management System Website.You can take more services from our website.Thanks for visit our website.</p>
				</div>
				<div class="col-lg-2 col-md-6 footer-links">
					<h4>Useful Links</h4>
					<ul>
						<li><a href="About Us.html">About Us</a></li>
						<li><a href="Manager.php">Admin</a></li>
						<li><a href="Menu.html">Online Order</a></li>
						<li><a href="Gallary.php">Gallary</a></li>
						<li><a href="contract.php">Contact Us</a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-6 footer-contact">
					<h4>Contact Us</h4>
					<p>
						Road No #01,Block A <br>
						Aftabnagor,Dhaka<br>
						Bangladesh<br>
						<strong>Phone:</strong> +880123456789<br>
						<strong>Email:</strong> foodhunter@yahoo.com<br>
					</p>
					<div class="social-links">
						<a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
						<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
						<a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
						<a href="https://www.youtube.com/" class="youtube"><i class="fa fa-youtube"></i></a>
						
					</div>
				</div>
				<div class="col-lg-3 col-md-6 footer-newsletter">
					<h4>Our Newsletter</h4>
					<p>-----------------------------------.<br>--------------------------<br>------------------------------------------.</p>
					<form accept="" method="post">
						<input type="email" name="email"><input type="submit" value="Subscribe">
					</form>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="copyright">
			2019 &copy; Copyright<strong> Food Hunter</strong>. All Right Reserved 
		</div>
		<div class="credits">
			Designed by CSESHANEWAZ
		</div>
	</div>
	
</footer>


<!--footer-->		
			

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>



</body>
</html>



