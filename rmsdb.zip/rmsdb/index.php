<!DOCTYPE html>
<html>
<head>
	<title>Resturant Management System</title>
	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <link rel="stylesheet" href="style-1.css">
<style type="text/css">
	body{
		background-image: url(image-1.jpg);
		background-size: cover;
	}
	.container{
		width: 300px;
		height: 300px;
		background-color: rgba(0,0,0,0.5);
		margin: 0 auto;
		margin-top: 40px;
		padding-top: 10px;
		padding-left: 50px;
		border-radius: 15px;
		-webkit-border-radius: 20px;
		-o-border-radius: 15px;
		-moz-border-radius: 15px;
	}

</style>

</head>
<body>
	<div class="container" style="width: 400px;margin-top: 150px;">


		<h1 style="color: white;font-family: Tw Cen MT;">Login</h1><br>
		<form class="form-group" action="func.php" method="post">
			<label style="color: white">Username :</label><br>
			<input type="text" name="username" class="form-control" placeholder="please enter username"><br>
			<label style="color: white">Password :</label><br>
			<input type="password" name="password" class="form-control" placeholder="please enter password"><br>
			<input type="submit" name="login_submit" class="btn btn-primary">
			<br>
			<a href="#"><b>Forget Password ??</b></a><br>
			<a href="#"><b>create account please</b></a>

		</form>
	</div>
	</div>
	</div>















<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script></script>
</body>
</html>