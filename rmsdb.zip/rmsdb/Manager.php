<!DOCTYPE html>
<html>
<head>
	<title>Manager</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="manager.css">

</head>
<body>
	<div class="jumbotron" style="background:url('manager-4.jpg') no-repeat;background-size: cover;height: 700px;">
		<div class="inner">
		<p>Admistrator</p>	
		</div>
		<br><br><br><br><br><br>
		<div class="container-fluid">
	<div class="row">
		
		<div class="col-md-3">
			<div class="list-group">
				<a href="" class="list-group-item active" style="background-color:#3498DB;color: #ffffff;border-color:#3498DB">Item</a>
				<a href="item_details.php" class="list-group-item">Item Details</a>
			</div>
			<hr>
			<div class="list-group">
				<a href="" class="list-group-item active" style="background-color:#3498DB;color: #ffffff;border-color:#3498DB">Customer</a>
				<a href="add_customer.php" class="list-group-item">Add New Customer</a>
				<a href="cust_details.php" class="list-group-item">Customers Details</a>
				<a href="" class="list-group-item">Remove Customer</a>
				<a href="" class="list-group-item">Payment</a>
			</div>
			<hr>
			<div class="list-group">
				<a href="" class="list-group-item active" style="background-color:#3498DB;color: #ffffff;border-color:#3498DB">Waiter</a>
				<a href="add_water.php" class="list-group-item">Add New Waiter</a>
				<a href="water_details.php" class="list-group-item">Waiter Details</a>
				<a href="" class="list-group-item">Remove Waiter Member</a>
			</div>
			


		</div>
		<div class="col-md-8">
			<div class="card">
				<div class="card-body" style="background-color:#3498DB;color: #ffffff;">
					<h3>Add New Item</h3>
				</div>
				<div class="card-body">
					<form class="form-group" action="func.php" method="post">
						<label>ID No :</label>
						<input type="text" name="id" class="form-control"><br>
						<label>Item Name :</label>
						<input type="text" name="name" class="form-control"><br>
						
					<label>Quality :</label>
						<select type="text" class="form-control" name="quality">
							<option value="Bangladesh">Bangladesh</option>
							<option value="Indian">Indian</option>
							<option value="Thai">Thai</option>
							<option value="Chines">Chines</option>
							<option value="South Indian">South Indian</option>
							<option value="Korean">Korean</option>
							<option value="Korean">Italian</option>
							
						</select><br>

						<label>Price Per Item :</label>
						<input type="text" name="price" class="form-control"><br>

						<label>Stock :</label>
						<input type="text" name="stock" class="form-control"><br>
						
						
						<input type="submit" class="btn btn-primary" name="item_submit" value="Submit">
						
					</form>

				</div>
			</div>
		</div>
		<div class="col-md-1"></div>

	</div>
	
</div>
	</div>











<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
</body>
</html>