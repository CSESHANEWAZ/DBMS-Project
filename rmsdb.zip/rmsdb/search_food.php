<html>
<head>
	<title>Item_Details</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>
<body>
<?php 
include("func.php");
if(isset($_POST['item_search_submit']))
{
	$contact=$_POST['search'];
	$query="select * from add_food where ID No.='$id'";
	$result=mysqli_query($con,$query);
	echo "<div class='container-fluid'
	<div class='card'>
	<div class='card-body'><a href='item_details.php' class='btn btn-primary'>Go back</a></div>
	img src='images/r1.jpeg' class='card-img-top'>
	<div class='card-body' style='background-color:#3498DB;color:#ffffff;'>
<table class='table table-hover'>
  <thead>
    <tr>
      <th>ID No.</th>
      <th>Name</th>
      <th>Quality</th>
      <th>Price</th>
      <th>Stock</th>
    </tr>
  </thead>
  <tbody>"
  ;
	while($row=mysqli_fetch_array($result)) {
	$id=$row['id'];
    $name=$row['name'];
    $quality=$row['quality'];
    $price=$row['price'];
    $stock=$row['stock'];
    echo "<tr>
    <td>$id</td>
    <td>$name</td>
    <td>$quality</td>
    <td>$price</td>
    <td>$stock</td>
    </tr>";
	}
	echo "</tbody></table></div></div></div>";
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" 
integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" 
crossorigin="anonymous"></script>
</body>
</html>