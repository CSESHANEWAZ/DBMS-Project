<?php
session_start();
$con=mysqli_connect("localhost","root","","rmsdb");

if(isset($_POST['add_customer']))
{
  $fname=$_POST['fname'];
   $lname=$_POST['lname'];
   $address=$_POST['address'];
    $email=$_POST['email'];
     $contact=$_POST['contact'];

     $query="insert into add_cust(fname,lname,address,email,contact)values('$fname','$lname','$address','$contact')";
     $result=mysqli_query($con,$query);
     if($result)
     {
      echo "<script>alert('Customer Added.')</script>";
      echo "<script>window.open('Manager.php','_self')</script>";

     }

}






?>